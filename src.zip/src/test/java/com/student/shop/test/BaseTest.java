package com.student.shop.test;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author student
 * @version 2023/03/14
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public abstract class BaseTest {

}

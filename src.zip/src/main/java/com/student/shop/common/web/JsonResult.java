package com.student.shop.common.web;

import com.student.shop.common.ResultBase;


public class JsonResult extends ResultBase {


}

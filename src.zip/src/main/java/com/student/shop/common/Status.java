package com.student.shop.common;

/**
 * @author Yike Du
 * @version 2023/3/15
 */
public enum Status {
    SUCCESS,
    FAIL,
    ;

}

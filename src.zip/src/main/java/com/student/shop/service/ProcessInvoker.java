package com.student.shop.service;


public abstract class ProcessInvoker {
    abstract  void process();
}

/**
 * 
 */
package com.student.shop.service;

/**
 * @author Yike Du
 * @date 2023-3-11
 *
 */
public interface IBaseService {

}

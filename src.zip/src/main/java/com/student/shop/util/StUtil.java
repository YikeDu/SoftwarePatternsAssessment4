/**
 * 
 */
package com.student.shop.util;

/**
 * @author Yike Du
 *
 */
public class StUtil {

}

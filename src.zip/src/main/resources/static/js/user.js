$(function () {
    $("#sub-nav-user").attr("class","active");
})